﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

using System;
using System.Collections.Generic;

namespace Doffin.ExampleClient
{
    /// <summary>
    /// Container class for a runnable Action. To be used together with the ArgumentParser class.
    /// </summary>
    class Command
    {
        public Action<Options, IList<string>> Action;
        public string Description;
        public int ArgumentCount;
    }
}