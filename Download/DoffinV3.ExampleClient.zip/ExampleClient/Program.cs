﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using Doffin.ClientLibrary;

namespace Doffin.ExampleClient
{
    /// <summary>
    /// Example program for invocations against Doffins service API.
    /// </summary>
    class Program
    {
        #region Command implementations

        private void DisapproveTranslation(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            client.DisapproveTranslation(args[0], args[1]);
            Console.Out.WriteLine("\tTranslation disapproved.");
        }

        private void ApproveTranslation(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            client.ApproveTranslation(args[0]);
            Console.Out.WriteLine("\tTranslation approved.");
        }

        private void GetTranslatedNotice(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            var translated = client.GetTranslatedNotice(args[0]);
            File.WriteAllText(args[1], translated);
            Console.Out.WriteLine("\tTranslated notice downloaded.");
        }

        private void UpdateNotice(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            var doc = XDocument.Load(args[1]);
            client.UpdateNotice(args[0], doc);
            Console.Out.WriteLine("\tNotice updated.");
        }

        private void GetPublishStatus(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            var status = client.GetPublishStatus(args[0]);
            Console.Out.WriteLine("\tStatus for publication: " + status);
        }

        private void PublishNotice(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            var doc = XDocument.Load(args[0]);
            var reference = client.PublishNotice(doc);
            Console.Out.WriteLine("\tNotice is published to Doffin. Reference is " + reference);
        }

        private void ValidateNotice(Options options, IList<string> args)
        {
            var client = GetDoffinClient(options);
            var doc = XDocument.Load(args[0]);
            var errMessages = client.validateNotice(doc);
            Console.Out.WriteLine("\tValidated notice:\n");
            foreach (var message in errMessages)
            {
                Console.Out.WriteLine("\tCode: \"" + (message.Code ?? "<null>") + "\", Message: \"" +(message.Message ?? "<null>")+"\".");
            }
        }

		private void GetNoticeContent(Options options, IList<string> args)
		{
			var client = GetDoffinClient(options);
			var translated = client.GetNoticeContent(args[0]);
			File.WriteAllText(args[1], translated);
			Console.Out.WriteLine("\tNotice content downloaded.");
		}

	    private void DownloadZip(Options options, IList<string> args)
	    {
			var client = GetDoffinClient(options);
			var result = client.DownloadZip(DateTime.Parse(args[0]));

		    if (result.Item1 == "OK")
		    {
				File.WriteAllBytes(args[1], result.Item2);
				Console.Out.WriteLine("\tAll notices downloaded.");    
		    }
		    else
		    {
				Console.Out.WriteLine(string.Format("\t{0}", result.Item1));
		    }
	    }

		private void GetNoticeHeaders(Options options, IList<string> args)
		{
			var client = GetDoffinClient(options);
			var translated = client.GetNoticeHeaders();
			File.WriteAllText(args[0], translated);
			Console.Out.WriteLine("\tNotice headers downloaded.");
		}

        #endregion Command implementations

        #region Boilerplate and housekeeping

        private readonly string[] _args;

        private readonly Dictionary<string, Command> _commands;

        private Program(string[] args)
        {
            _args = args;
            _commands = new Dictionary<string, Command>();
			_commands.Add("validate", new Command { Action = ValidateNotice, Description = "Validate a notice.\nArguments:\n\tNoticeFile\tA notice xml file to publish.", ArgumentCount = 1 });
			_commands.Add("publish", new Command { Action = PublishNotice, Description = "Publish a Notice to Doffin.\nArguments:\n\tNoticeFile\tA notice xml file to publish.", ArgumentCount = 1 });
            _commands.Add("getstatus", new Command { Action = GetPublishStatus, Description = "Get publication status for a notice.\nArguments:\n\tDoffinRefNr\tThe reference to a prevoiusly published notice.", ArgumentCount = 1 });
            _commands.Add("update", new Command { Action = UpdateNotice, Description = "Update a ongoing publication with new notice contents.\nArguments:\n\tDoffinRefNr\tThe reference to a, prevoiusly sent for publication, notice.\n\tNotice\t\tNew contents for the notice to publish.", ArgumentCount = 2 });
            _commands.Add("approve", new Command { Action = ApproveTranslation, Description = "Approve a translation.\nArguments:\n\tDoffinRefNr\tThe reference to a prevoiusly published notice.", ArgumentCount = 1 });
            _commands.Add("disapprove", new Command { Action = DisapproveTranslation, Description = "Disapprove a translation.\nArguments:\n\tDoffinRefNr\tThe reference to a prevoiusly published notice.\n\tReason\t\tA text describing why the translation is erroneous.", ArgumentCount = 2 });
			_commands.Add("translation", new Command { Action = GetTranslatedNotice, Description = "Get translated version of a notice.\nArguments:\n\tDoffinRefNr\tThe reference to a prevoiusly published notice.\n\tFilename\tWhere to save the translation.", ArgumentCount = 2 });
			_commands.Add("getnotice", new Command { Action = GetNoticeContent, Description = "Get  xml content for active and published notice.\nArguments:\n\tDoffinRefNr\tThe reference to a prevoiusly published notice.\n\tFilename\tWhere to save the translation.", ArgumentCount = 2 });
			_commands.Add("download", new Command { Action = DownloadZip, Description = "Returns all notices published at a given date as a Zip archive.\nArguments:\n\tZip Date\tThe date in format YYYY-MM-DD.\n\tFilename\tWhere to save the zip archive.", ArgumentCount = 2 });
			_commands.Add("headers", new Command { Action = GetNoticeHeaders, Description = "Get notice headers for publications made in the last 24hrs.\nArguments:\n\tFilename\tWhere to save headers.", ArgumentCount = 1 });
        }

        private static void Main(string[] args)
        {
            new Program(args).Run();
            Console.ReadLine();
        }

        private void Run()
        {
            var parser = new ArgumentParser(_commands);
            Action action;
            if (parser.TryParseArguments(_args, out action))
            {
                action();
            }
        }

        private IDoffinClient GetDoffinClient(Options options)
        {
            var url = new Uri(options.Address);
            return new DoffinClient(url, options.Username, options.Password);
        }
        #endregion Boilerplate and housekeeping
    }
}
