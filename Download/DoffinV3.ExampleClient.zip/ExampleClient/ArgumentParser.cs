﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

using System;
using System.Collections.Generic;
using System.IO;
using Mono.Options;

namespace Doffin.ExampleClient
{
    /// <summary>
    /// Class for handling of commandline arguments in conjunction with Mono.Options
    /// </summary>
    class ArgumentParser
    {
        private readonly IDictionary<string, Command> _availableCommands;

        public ArgumentParser(IDictionary<string,Command> availableCommands)
        {
            _availableCommands = availableCommands;
        }

        public bool TryParseArguments(string[] args, out Action action)
        {
            string commandText = null;
            action = null;
            var options = new Options();
            options.ShowHelp = args.Length == 0;

            var p = new OptionSet()
                    {
                        {"a|address=", "Base Address to Doffin service.", x => options.Address = x},
                        {"u|username=", "username for connecting.", x => options.Username = x},
                        {"p|password=", "password. If not specified, will prompt for one.", x => options.Password = x},
                        {"h|help", "show this message and exit", x => options.ShowHelp = x != null},
                        {"l|list", "list commands", x => options.ListCommands = x != null},
                    };

            List<string> extra;
            try
            {
                extra = p.Parse(args);
            }
            catch (OptionException e)
            {
                ShowErrorMessage(e.Message);
                return false;
            }
            if (extra.Count > 0)
            {
                commandText = extra[0];
                extra.RemoveAt(0);
            }

            if (options.ShowHelp)
            {
                ShowHelp(p);
                return false;
            }

            if (options.ListCommands)
            {
                ListCommands(Console.Out);
                return false;
            }

            if (!String.IsNullOrEmpty(commandText))
            {
                if (!_availableCommands.ContainsKey(commandText))
                {
                    ShowErrorMessage("Unknown command \"" + commandText + "\".");
                    return false;
                }

                if (_availableCommands[commandText].ArgumentCount != extra.Count)
                {
                    ShowErrorMessage("Wrong number of arguments to command \""+commandText+"\".");
                    return false;
                }

                if (options.Password == null)
                {
                    options.Password = PromptForPassword();
                }

                action = () => _availableCommands[commandText].Action(options,extra);
                return true;
            }

            ShowHelp(p);
            return false;
        }

        private void ListCommands(TextWriter writer)
        {
            writer.WriteLine("Available commands:");
            writer.WriteLine("###################\n");

            foreach (var key in _availableCommands.Keys)
            {
                var command = _availableCommands[key];
                writer.WriteLine("# " + key + " #\t:\t" + command.Description+"\n\n");
            }
        }

        private static void ShowErrorMessage(string message)
        {
            Console.Write("Doffin.ExampleClient: ");
            Console.WriteLine(message);
            Console.WriteLine("Try Doffin.ExampleClient --help' for more information.");
        }

        private static void ShowHelp(OptionSet p)
        {
            Console.WriteLine("Usage: Doffin.ExampleClient [OPTIONS]+ command [arguments]");
            Console.WriteLine("Execute a command against the Doffin service.");
            Console.WriteLine();
            Console.WriteLine("Options:");
            p.WriteOptionDescriptions(Console.Out);
        }

        private string PromptForPassword()
        {
            string pass = "";
            Console.Write("Enter password: ");
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);
                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    pass += key.KeyChar;
                    Console.Write("*");
                }
                else
                {
                    if (key.Key == ConsoleKey.Backspace && pass.Length > 0)
                    {
                        pass = pass.Substring(0, (pass.Length - 1));
                        Console.Write("\b \b");
                    }
                }
            }
            while (key.Key != ConsoleKey.Enter);
            Console.WriteLine();

            return pass;
        }
    }
}