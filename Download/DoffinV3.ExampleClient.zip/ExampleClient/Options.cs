﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

namespace Doffin.ExampleClient
{
    /// <summary>
    /// Possible command line options extracted via the ArgumentParser
    /// </summary>
    class Options
    {
        public bool ShowHelp;
        public string Address;
        public string Username;
        public string Password;
        public bool ListCommands;
    }
}