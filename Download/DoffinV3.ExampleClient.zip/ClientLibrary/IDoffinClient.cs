﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

using System;
using System.Collections.Generic;
using System.Xml.Linq;
using Eps.WebApiDtos.PublicApi;

namespace Doffin.ClientLibrary
{
    public interface IDoffinClient
    {
        PublishStatus GetPublishStatus(string doffinRefNr);
        string PublishNotice(XDocument notice);
        void UpdateNotice(string doffinRefNr, XDocument notice);
        string GetTranslatedNotice(string doffinRefNr);
        void ApproveTranslation(string doffinRefNr);
        void DisapproveTranslation(string doffinRefNr, string reason);
        IList<ValidationMessage> validateNotice(XDocument notice);
		string GetNoticeContent(string doffinRefNr);
		Tuple<string, byte[]> DownloadZip(DateTime dt);
		string GetNoticeHeaders();
    }
}