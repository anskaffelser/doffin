﻿#region Copyright header
// Copyright © EUS Holdings LTD (hereinafter “eu-supply”) 2013. All rights reserved.
#endregion Copyright header

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml.Linq;
using Eps.WebApiDtos.PublicApi;
using Newtonsoft.Json;

namespace Doffin.ClientLibrary
{
    /// <summary>
    /// Example implementation of a client to Doffin.
    /// Names of the methods are self-explationary.
    /// You can use this as a starter when creating your own Doffin-client.
    /// 
    /// It has no real error handling, though, and assumes the "happy flow".
    /// This because how to react on different errors, and what kind of errors are
    /// to be expected, differ wildly depending of how the rest of your business logic
    /// is constructed.
    /// </summary>
    public class DoffinClient : IDoffinClient
    {
        private readonly Uri _baseUrl;
        private readonly string _username;
        private readonly string _password;

        public DoffinClient(Uri baseUrl, string username, string password)
        {
            _baseUrl = baseUrl;
            _username = username;
            _password = password;
        }

        #region Implementation of IDoffinClient
        public PublishStatus GetPublishStatus(string doffinRefNr)
        {
			var url = GetFullUrl("doffin/notice/" + doffinRefNr);
            var notice = Get<Notice>(url);
            var status = (PublishStatus) Enum.Parse(typeof (PublishStatus), notice.PublishStatus);
            return status;
        }

        public string PublishNotice(XDocument notice)
        {
            var url = GetFullUrl("doffin/notice");
            var bytes = Encoding.UTF8.GetBytes(notice.ToString());
            Uri createLocation;
            var doffinRefNr = Post<byte[], string>(url, bytes, out createLocation);
            return doffinRefNr;
        }

        public void UpdateNotice(string doffinRefNr, XDocument notice)
        {
			var url = GetFullUrl("doffin/notice/" + doffinRefNr);
            var bytes = Encoding.UTF8.GetBytes(notice.ToString());
            Put<byte[], object>(url, bytes);
        }

        public string GetTranslatedNotice(string doffinRefNr)
        {
			var url = GetFullUrl("doffin/translation/" + doffinRefNr);
            using (var client = GetConfiguredHttpClient())
            {
                var response = client.GetAsync(url).Result;
                return response.Content.ReadAsStringAsync().Result;
            }
        }

        public void ApproveTranslation(string doffinRefNr)
        {
            var request = new ApproveRequest() {EpsRefNr = doffinRefNr};
			var url = GetFullUrl("doffin/translation/approve");
            Post<ApproveRequest, object>(url, request);
        }

        public void DisapproveTranslation(string doffinRefNr, string reason)
        {
            var request = new DisapproveRequest() { EpsRefNr = doffinRefNr, DissaprovalReason = reason};
			var url = GetFullUrl("doffin/translation/disapprove");
            Post<DisapproveRequest, object>(url, request);
        }

        public IList<ValidationMessage> validateNotice(XDocument notice)
        {
			var url = GetFullUrl("doffin/validate");
            var bytes = Encoding.UTF8.GetBytes(notice.ToString());
            using (var client = GetConfiguredHttpClient())
            {
                return Post<byte[], IList<ValidationMessage>>(url, bytes);
            }
        }

		public string GetNoticeContent(string doffinRefNr)
		{
			var url = GetFullUrl("doffin/noticecontent/" + doffinRefNr);
			using (var client = GetConfiguredHttpClient())
			{
				var response = client.GetAsync(url).Result;
				return response.Content.ReadAsStringAsync().Result;
			}
		}

		public Tuple<string, byte[]> DownloadZip(DateTime dt)
		{
			var url = GetFullUrl("doffin/notices/download/" + dt.ToString("yyyy-MM-dd"));
			using (var client = GetConfiguredHttpClient())
			{
				var response = client.GetAsync(url).Result;

				if (response.StatusCode == HttpStatusCode.OK)
				{
					return new Tuple<string, byte[]>( "OK", response.Content.ReadAsByteArrayAsync().Result );
				}
				else
				{
					return new Tuple<string, byte[]>(string.Format("Error: {0}", response.ReasonPhrase), null);
				}
			}
		}

		public string GetNoticeHeaders()
		{
			var url = GetFullUrl("doffin/noticeheaders");
			using (var client = GetConfiguredHttpClient())
			{
				var response = client.GetAsync(url).Result;
				return response.Content.ReadAsStringAsync().Result;
			}
		}

        #endregion Implementation of IDoffinClient

        #region Helper methods
        private T Get<T>(string url)
        {
            using (var client = GetConfiguredHttpClient())
            {
                var response = client.GetAsync(url).Result;
                return JsonDeserialize<T>(response);
            }
        }

        private U Post<T, U>(string url, T item, out Uri createLocation)
        {
            createLocation = null;
            using (var client = GetConfiguredHttpClient())
            {
                var response = client.PostAsJsonAsync(url, item).Result;
                if (response.StatusCode == HttpStatusCode.Created)
                {
                    createLocation = new Uri(response.ReasonPhrase);
                    return JsonDeserialize<U>(response);
                }
                return default(U);
            }
        }

        private U Post<T, U>(string url, T item)
        {
            using (var client = GetConfiguredHttpClient())
            {
                var response = client.PostAsJsonAsync(url, item).Result;
                return JsonDeserialize<U>(response);
            }
        }


        private U Put<T, U>(string url, T item)
        {
            using (var client = GetConfiguredHttpClient())
            {
                var response = client.PutAsJsonAsync(url, item).Result;
                if (response.StatusCode == HttpStatusCode.Created)
                {
                    return JsonDeserialize<U>(response);
                }
                return default(U);
            }
        }

        private HttpClient GetConfiguredHttpClient()
        {
            var handler = new HttpClientHandler() {Credentials = new NetworkCredential(_username, _password)};
            var client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }

        private T JsonDeserialize<T>(HttpResponseMessage response)
        {
            var serializer = new JsonSerializer();
            using (
                var jsonReader =
                    new JsonTextReader(new StreamReader(response.Content.ReadAsStreamAsync().Result)))
            {
                return serializer.Deserialize<T>(jsonReader);
            }
        }

        private string GetFullUrl(string relativeUrl)
        {
            return _baseUrl.AbsoluteUri.EndsWith("/")
                ? _baseUrl.AbsoluteUri + relativeUrl
                : _baseUrl.AbsoluteUri + "/" + relativeUrl;
        }
        #endregion Helper methods
    }
}
